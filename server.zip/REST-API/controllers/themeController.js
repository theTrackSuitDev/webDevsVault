const { themeModel } = require("../models");
const { userModel } = require("../models");
const { newPost } = require("./postController");

function getThemes(req, res, next) {
    themeModel
        .find()
        .populate("userId")
        .then((themes) => res.json(themes))
        .catch(next);
}

function getTheme(req, res, next) {
    const { themeId } = req.params;

    themeModel
        .findById(themeId)
        .populate("userId")
        // .populate("subscribers")
        .then((theme) => res.json(theme))
        .catch(next);
}

function createTheme(req, res, next) {
    const { title, technology, description, resourceUrl, imageUrl} = req.body;
    const { _id: userId } = req.user;
    let newTheme;

    themeModel
        .create({
            title,
            technology,
            description,
            resourceUrl,
            imageUrl,
            userId,
            subscribers: [],
            posts: [],
        })
        .then((theme) => {
            newTheme = theme;
            updateUser(userId, newTheme);
        })
        .catch(next);

    function updateUser(userId, newTheme) {
        userModel
            .findByIdAndUpdate(
                { _id: userId },
                { $addToSet: { themes: newTheme._id } },
                { new: true }
            )
            .then((updatedUser) => {
                res.status(200).json(newTheme._id);
            })
            .catch(next);
    }

}

function subscribe(req, res, next) {
    const themeId = req.params.themeId;
    const { _id: userId } = req.user;

    Promise.all([
        themeModel
            .findByIdAndUpdate(
                { _id: themeId },
                { $addToSet: { subscribers: userId } },
                { new: true }
            )
            .populate("userId"),
        userModel
            .findByIdAndUpdate(
                { _id: userId },
                { $addToSet: { subs: themeId } },
                { new: true }
            )
    ])
        .then(([updatedTheme, updatedUser]) => {
            if (updatedTheme && updatedUser) {
                res.status(200).json(updatedTheme);
            } else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

function unsubscribe(req, res, next) {
    const themeId = req.params.themeId;
    const { _id: userId } = req.user;

    Promise.all([
        themeModel
            .findByIdAndUpdate(
                { _id: themeId },
                { $pull: { subscribers: userId } },
                { new: true }
            )
            .populate("userId"),
        userModel
            .findByIdAndUpdate(
                { _id: userId },
                { $pull: { subs: themeId } },
                { new: true }
            )
    ])
        .then(([updatedTheme, updatedUser]) => {
            if (updatedTheme && updatedUser) {
                res.status(200).json(updatedTheme);
            } else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

function editTheme(req, res, next) {
    const { title, technology, description, resourceUrl, imageUrl } = req.body;
    const { themeId } = req.params;
    const { _id: userId } = req.user;

    themeModel.findOneAndUpdate({ _id: themeId, userId }, { title, technology, description, resourceUrl, imageUrl }, { new: true })
        .then(updatedProject => {
            if (updatedProject) {
                res.status(200).json(updatedProject._id);
            }
            else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

function deleteTheme(req, res, next) {
    const { themeId } = req.params;
    const { _id: userId } = req.user;

    Promise.all([
        themeModel.findOneAndDelete({ _id: themeId }),
        userModel.findOneAndUpdate({ _id: userId }, { $pull: { themes: themeId } }),
        //Update all users that subscribed!
        userModel.updateMany(
            { subs: { $in: [themeId] } }, { $pull: { subs: themeId } }
        )
    ])
        .then(([deletedOne, _]) => {
            if (deletedOne) {
                res.status(200).json(deletedOne)
            } else {
                res.status(401).json({ message: `Not allowed!` });
            }
        })
        .catch(next);
}

module.exports = {
    getThemes,
    createTheme,
    getTheme,
    subscribe,
    unsubscribe,
    editTheme,
    deleteTheme
};
